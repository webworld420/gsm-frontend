<nav class="navItems">
                        <ul class="d-flex">
                            <li><a href="">Shop</a></li>
                            <li><a href="">Team <img src="./Images/SVG icons/arrowDown.svg" alt=""></a></a>
                                <ul class="Sub-menu">
                                    <li> <a href="">Dota 2</a></li>
                                    <li> <a href="">Valorant</a></li>
                                    <li> <a href="">Rocket Leauge</a></li>
                                    <li> <a href="">Rainbow Sixe Siege</a></li>
                                    <li> <a href="">Pubg Mobile</a></li>
                                    <li> <a href="">Mobile Legends</a></li>
                                    <li> <a href="">League of Legends</a></li>
                                    <li> <a href="">Ambassadors</a></li>
                                </ul>
                            </li>
                            <li><a href="">About</a></li>
                            <li><a href="">More <img src="./Images/SVG icons/arrowDown.svg" alt=""></a>
                                <ul class="Sub-menu2">
                                    <li><a href="">Partners</a></li>
                                    <li><a href="">Media</a></li>
                                    <li><a href="">FAQ</a></li>
                                </ul>
                                <span>
                            <li class="nav-ico"><a href=""><img src="./Images/SVG icons/search.svg" alt=""></a></li>
                            <li class="nav-ico"><a href=""><img src="./Images/SVG icons/user.svg" alt=""></a></li>
                            <li class="nav-ico"> <a href=""><img src="./Images/SVG icons/cart.svg" alt=""></a></li>
                            </span>
                            </li>
                        </ul>
                    </nav>
                    <nav class="Mobile-navItems" id="MobileNav">
                        <div class="logo">
                            <img src="./Images/logo.png" alt="">
                        </div>
                        <ul class="d-flex">
                            <li><a href="">Shop</a></li>
                            <li><a>Team <img src="./Images/SVG icons/arrowDown.svg" alt=""></a></a>
                                <ul class="Sub-menu">
                                    <li> <a href="">Dota 2</a></li>
                                    <li> <a href="">Valorant</a></li>
                                    <li> <a href="">Rocket Leauge</a></li>
                                    <li> <a href="">Rainbow Sixe Siege</a></li>
                                    <li> <a href="">Pubg Mobile</a></li>
                                    <li> <a href="">Mobile Legends</a></li>
                                    <li> <a href="">League of Legends</a></li>
                                    <li> <a href="">Ambassadors</a></li>
                                </ul>
                            </li>
                            <li><a href="">About</a></li>
                            <li><a>More <img src="./Images/SVG icons/arrowDown.svg" alt=""></a>
                                <ul class="Sub-menu2">
                                    <li><a href="">Partners</a></li>
                                    <li><a href="">Media</a></li>
                                    <li><a href="">FAQ</a></li>
                                </ul>
                            </li>
                        </ul>
                        <span>
                            <img src="./Images/SVG icons/times.svg" alt="" id="times">
                        </span>
                        <div class="iconsImage">
                            <li><a href=""><img src="./Images/SVG icons/search.svg" alt=""></a></li>
                            <li><a href=""><img src="./Images/SVG icons/user.svg" alt=""></a></li>
                        </div>
                    </nav>